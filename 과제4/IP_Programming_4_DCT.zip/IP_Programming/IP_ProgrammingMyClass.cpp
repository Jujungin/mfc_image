#include "stdafx.h"
#include "IP_ProgrammingMyClass.h"
#include <cmath>

#define PI 3.14159265
#define CLIP(x) x > 255 ? 255 : x < 0? 0 : x

CIP_ProgrammingMyClass::CIP_ProgrammingMyClass(void)
	: m_pucBMP(NULL)
	, m_pucImgbuf(NULL)
	, m_uiWidth(0)
	, m_uiHeight(0)
	, m_pucHistEqualImgBuf(NULL)
	, m_pucForwardDCTbuf(NULL)
	, m_pucTempDCTbuf(NULL)
	, m_pucInverseDCTbuf(NULL)
{
	//	set the BMP header information
	m_BMPheader.biSize			=	sizeof(BITMAPINFOHEADER);
	m_BMPheader.biPlanes		=	1;
	m_BMPheader.biBitCount		=	24;
	m_BMPheader.biCompression	=	BI_RGB;
	m_BMPheader.biSizeImage		=	0;
	m_BMPheader.biXPelsPerMeter	=	0;
	m_BMPheader.biYPelsPerMeter	=	0;
	m_BMPheader.biClrUsed		=	0;
	m_BMPheader.biClrImportant	=	0;
}

CIP_ProgrammingMyClass::~CIP_ProgrammingMyClass(void)
{
	if(m_pucBMP)
		free(m_pucBMP);
	if(m_pucImgbuf)
		memory_free2D(m_pucImgbuf);
	if(m_pucHistEqualImgBuf)
		memory_free2D(m_pucHistEqualImgBuf);
	if(m_pucForwardDCTbuf)
		memory_free2D(m_pucForwardDCTbuf);
	if(m_pucTempDCTbuf)
		memory_free2D(m_pucTempDCTbuf);
	if(m_pucInverseDCTbuf)
		memory_free2D(m_pucInverseDCTbuf);
}

UCHAR** CIP_ProgrammingMyClass::memory_alloc2D(UINT32 height, UINT32 width)
{
	UCHAR**	ppMem2D = 0;
	UINT	i;

	//arrary of pointer
	ppMem2D = (UCHAR**)calloc(sizeof(UCHAR*),height);

	if(ppMem2D == 0)
	{
		return 0;
	}
	*ppMem2D = (UCHAR*)calloc(sizeof(UCHAR),height*width);

	if((*ppMem2D) == 0)
	{
		//free the memory of array of pointer
		free (ppMem2D);
		return 0;
	}

	for(i=1; i<height; i++)
	{
		ppMem2D[i] = ppMem2D[i-1] + width;
	}

	return ppMem2D;
}
int CIP_ProgrammingMyClass::memory_free2D(UCHAR** ppMemAllocated)
{
	if(ppMemAllocated == 0)
	{
		return -1;
	}

	free (ppMemAllocated[0]);
	free (ppMemAllocated);
	ppMemAllocated = NULL;

	return 0;
}
void CIP_ProgrammingMyClass::MyClass_MakeGrayImagetoBMP()
{
	m_BMPheader.biWidth = m_uiWidth;
	m_BMPheader.biHeight = m_uiHeight;

	int i,j,idx = 0;

	m_pucBMP = (UCHAR*)calloc(sizeof(UCHAR), m_uiWidth * m_uiHeight * 3);

	for(i=m_uiHeight-1; i>=0; i--)
	{
		for(j=0; j<m_uiWidth; j++)
		{
			m_pucBMP[idx++] = m_pucImgbuf[i][j];
			m_pucBMP[idx++] = m_pucImgbuf[i][j];
			m_pucBMP[idx++] = m_pucImgbuf[i][j];
		}
	}
}

void CIP_ProgrammingMyClass::MyClass_MakeGrayImagetoBMP(UCHAR** Imgbuf)
{
	m_BMPheader.biWidth = m_uiWidth;
	m_BMPheader.biHeight = m_uiHeight;

	int i,j,idx = 0;

	m_pucBMP = (UCHAR*)calloc(sizeof(UCHAR), m_uiWidth * m_uiHeight * 3);

	for(i=m_uiHeight-1; i>=0; i--)
	{
		for(j=0; j<m_uiWidth; j++)
		{
			m_pucBMP[idx++] = Imgbuf[i][j];
			m_pucBMP[idx++] = Imgbuf[i][j];
			m_pucBMP[idx++] = Imgbuf[i][j];
		}
	}
}


void CIP_ProgrammingMyClass::MyClass_MakeHistogram(UCHAR** HistImgbuf, float HistArray[256])
{
	int i,j;
	int width = m_uiWidth;	             
	int height = m_uiHeight;

	//8-bit depth �ӽ� �迭 ����
	int Image_Histogram[256] = {0,};

	//Histogram Calculation
	for(i=0; i<height; i++)
	{
		for(j=0; j<width; j++)
		{
			Image_Histogram[HistImgbuf[i][j]]++;
		}
	}
	//Histogram Normalization
	float Image_Area = (float)(height*width);
	for(i=0; i<256; i++)
	{
		HistArray[i] = Image_Histogram[i]/Image_Area;
	}
}


void CIP_ProgrammingMyClass::MyClass_MakeHistogramEqualization ()
{
    int i,j;
    UINT width = m_uiWidth;
    UINT height = m_uiHeight;

    //���� ������ Histogram ����
    float Image_Histogram_Equalization[256] = {0,};
    MyClass_MakeHistogram(m_pucImgbuf, Image_Histogram_Equalization);

    //Histogram ���� �� ���
    double CDF[256] = {0.0, };
    CDF[0] = Image_Histogram_Equalization[0];
    for(i=1; i<256; i++)
    {
        CDF[i] = CDF[i-1] + Image_Histogram_Equalization[i];
    }

    //Histogram equalization ���� �޸� �Ҵ�
    m_pucHistEqualImgBuf = memory_alloc2D(height,width);

    //Histogram equalization image ����
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            m_pucHistEqualImgBuf[i][j] =
                         (UCHAR) (CDF[m_pucImgbuf[i][j]]*255);
        }
    }
}

void CIP_ProgrammingMyClass::MyClass_COPY(CIP_ProgrammingMyClass *pImage)
{
	m_BMPheader = pImage->m_BMPheader;
	m_uiWidth   = pImage->m_uiWidth;
	m_uiHeight  = pImage->m_uiHeight;
	m_pucImgbuf = memory_alloc2D(m_uiHeight,m_uiWidth);
	for(int i=0; i<m_uiHeight; i++)
		memcpy(m_pucImgbuf[i],pImage->m_pucImgbuf[i],sizeof(UCHAR)*m_uiWidth);
}

double** CIP_ProgrammingMyClass::memory_alloc2D(int height, int width)
{
	double**	ppMem2D = 0;
	UINT	i;

	//arrary of pointer
	ppMem2D = (double**)calloc(sizeof(double*),height);

	if(ppMem2D == 0)
	{
		return 0;
	}
	*ppMem2D = (double*)calloc(sizeof(double),height*width);

	if((*ppMem2D) == 0)
	{
		//free the memory of array of pointer
		free (ppMem2D);
		return 0;
	}

	for(i=1; i<height; i++)
	{
		ppMem2D[i] = ppMem2D[i-1] + width;
	}

	return ppMem2D;
}

int CIP_ProgrammingMyClass::memory_free2D(double** ppMemAllocated)
{
	if(ppMemAllocated == 0)
	{
		return -1;
	}

	free (ppMemAllocated[0]);
	free (ppMemAllocated);
	ppMemAllocated = NULL;

	return 0;
}

void CIP_ProgrammingMyClass::MyClass_MakeBlock(int DCT_blocksize, int select)
{
	if(select == 1)//FDCT
	{
		m_pucForwardDCTbuf = memory_alloc2D((int)m_uiHeight,(int)m_uiWidth);
		m_pucTempDCTbuf = memory_alloc2D((int)m_uiHeight,(int)m_uiWidth);
	}
	if(select == 0)//IDCT
		m_pucInverseDCTbuf = memory_alloc2D((int)m_uiHeight,(int)m_uiWidth);

	double** DCT_block = memory_alloc2D(DCT_blocksize,DCT_blocksize);
	
	for(int i=0;i<m_uiHeight;i+=DCT_blocksize)
	{
		for(int j=0;j<m_uiWidth;j+=DCT_blocksize)
		{
			for(int m=0;m<DCT_blocksize;m++)
			{
				for(int n=0;n<DCT_blocksize;n++)
				{
					if(select == 1)
						DCT_block[m][n] = (double) m_pucImgbuf[i+m][j+n];
					if(select == 0)
						DCT_block[m][n] = 
										(double) m_pucTempDCTbuf[i+m][j+n];
				}
			}
			if(select == 1)
				MyClass_ForwardDCT(DCT_block, DCT_blocksize, i, j);
			if(select == 0)
				MyClass_InverseDCT(DCT_block, DCT_blocksize, i, j);
		}
	}
	memory_free2D(DCT_block);
}

void CIP_ProgrammingMyClass::MyClass_ForwardDCT(double** DCT_Block, int DCT_blocksize, int row, int col)
{
	double Sum, Cu, Cv, DCT_max=0;
	
	for(int u=0; u<DCT_blocksize; u++)
	{
		if(u==0)
			Cu = 1/sqrt(DCT_blocksize);
		else
			Cu = sqrt(2.0/DCT_blocksize);
		for(int v=0; v<DCT_blocksize; v++)
		{
			Sum=0;
			if(v==0) 
				Cv = 1/sqrt(DCT_blocksize);
			else 
				Cv = sqrt(2.0/DCT_blocksize);
			for(int y=0; y<DCT_blocksize; y++)
			{
				for(int x=0; x<DCT_blocksize; x++)
				{
					double cosVal1 = Cu*cos((2*y+1)*v*PI/(2*DCT_blocksize));
					double cosVal2 = Cv*cos((2*x+1)*u*PI/(2*DCT_blocksize));

					Sum+=DCT_Block[y][x]*cosVal1*cosVal2;
				}
			}
			m_pucTempDCTbuf[u+row][v+col] = Sum;
			m_pucForwardDCTbuf[u+row][v+col] = CLIP(Sum);
		}
	}
}

void CIP_ProgrammingMyClass::MyClass_InverseDCT(double** DCT_Block, int DCT_blocksize, int row, int col)
{
	double idct = 0;
	double Sum = 0;
	double Cu, Cv;
	
	for(int y=0; y<DCT_blocksize; y++)
	{
		for(int x=0; x<DCT_blocksize; x++)
		{
			Sum=0;
			for(int u=0; u<DCT_blocksize; u++)
			{
				if(u==0)
					Cu = 1/sqrt(DCT_blocksize);
				else
					Cu = sqrt(2.0/DCT_blocksize);
				for(int v=0; v<DCT_blocksize; v++)
				{
					if(v==0) 
						Cv = 1/sqrt(DCT_blocksize);
					else 
						Cv = sqrt(2.0/DCT_blocksize);

					double cosVal1 = Cu*cos((2*y+1)*v*PI/(2*DCT_blocksize));
					double cosVal2 = Cv*cos((2*x+1)*u*PI/(2*DCT_blocksize));

					Sum+=DCT_Block[u][v]*cosVal1*cosVal2;
				}
			}
			m_pucInverseDCTbuf[y+row][x+col] = CLIP(Sum);
		}
	}
}

void CIP_ProgrammingMyClass::MyClass_MakeGrayImagetoBMP(double** Imgbuf)
{
	m_BMPheader.biWidth = m_uiWidth;
	m_BMPheader.biHeight = m_uiHeight;

	int i,j,idx = 0;

	m_pucBMP = (UCHAR*)calloc(sizeof(UCHAR), m_uiWidth * m_uiHeight * 3);

	for(i=m_uiHeight-1; i>=0; i--)
	{
		for(j=0; j<m_uiWidth; j++)
		{
			m_pucBMP[idx++] = Imgbuf[i][j];
			m_pucBMP[idx++] = Imgbuf[i][j];
			m_pucBMP[idx++] = Imgbuf[i][j];
		}
	}
}