// ImageDCTDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IP_Programming.h"
#include "ImageDCTDlg.h"
#include "afxdialogex.h"


// CImageDCTDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CImageDCTDlg, CDialogEx)

CImageDCTDlg::CImageDCTDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CImageDCTDlg::IDD, pParent)
	, m_DlgBlockSize(0)
{

}

CImageDCTDlg::~CImageDCTDlg()
{
}

void CImageDCTDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, m_DlgBlockSize);
}


BEGIN_MESSAGE_MAP(CImageDCTDlg, CDialogEx)
END_MESSAGE_MAP()


// CImageDCTDlg �޽��� ó�����Դϴ�.
