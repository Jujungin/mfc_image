#pragma once

#include "./IppImage/IppImage.h"

void Sobel(IppByteImage& img, IppByteImage& imgEdge);