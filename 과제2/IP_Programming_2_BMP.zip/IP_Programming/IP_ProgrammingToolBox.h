#pragma once
#include "IP_IO.h"

class CIP_ProgrammingToolBox
{
public:
	CIP_IO io;

public:
	CIP_ProgrammingToolBox(void);
	~CIP_ProgrammingToolBox(void);
};

