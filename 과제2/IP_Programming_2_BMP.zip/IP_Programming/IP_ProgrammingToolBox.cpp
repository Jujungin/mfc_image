#include "stdafx.h"
#include "IP_ProgrammingToolBox.h"

CIP_ProgrammingToolBox::CIP_ProgrammingToolBox(void)
{
}


CIP_ProgrammingToolBox::~CIP_ProgrammingToolBox(void)
{
}
