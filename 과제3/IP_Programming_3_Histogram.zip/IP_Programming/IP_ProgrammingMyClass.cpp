#include "stdafx.h"
#include "IP_ProgrammingMyClass.h"


CIP_ProgrammingMyClass::CIP_ProgrammingMyClass(void)
	: m_pucBMP(NULL)
	, m_pucImgbuf(NULL)
	, m_uiWidth(0)
	, m_uiHeight(0)
	, m_pucHistEqualImgBuf(NULL)
{
	//	set the BMP header information
	m_BMPheader.biSize			=	sizeof(BITMAPINFOHEADER);
	m_BMPheader.biPlanes		=	1;
	m_BMPheader.biBitCount		=	24;
	m_BMPheader.biCompression	=	BI_RGB;
	m_BMPheader.biSizeImage		=	0;
	m_BMPheader.biXPelsPerMeter	=	0;
	m_BMPheader.biYPelsPerMeter	=	0;
	m_BMPheader.biClrUsed		=	0;
	m_BMPheader.biClrImportant	=	0;
}
CIP_ProgrammingMyClass::~CIP_ProgrammingMyClass(void)
{
	if(m_pucBMP)
		free(m_pucBMP);
	if(m_pucImgbuf)
		memory_free2D(m_pucImgbuf);
	if(m_pucHistEqualImgBuf)
		memory_free2D(m_pucHistEqualImgBuf);

}
UCHAR** CIP_ProgrammingMyClass::memory_alloc2D(UINT32 height, UINT32 width)
{
	UCHAR**	ppMem2D = 0;
	UINT	i;

	//arrary of pointer
	ppMem2D = (UCHAR**)calloc(sizeof(UCHAR*),height);

	if(ppMem2D == 0)
	{
		return 0;
	}
	*ppMem2D = (UCHAR*)calloc(sizeof(UCHAR),height*width);

	if((*ppMem2D) == 0)
	{
		//free the memory of array of pointer
		free (ppMem2D);
		return 0;
	}

	for(i=1; i<height; i++)
	{
		ppMem2D[i] = ppMem2D[i-1] + width;
	}

	return ppMem2D;
}
int CIP_ProgrammingMyClass::memory_free2D(UCHAR** ppMemAllocated)
{
	if(ppMemAllocated == 0)
	{
		return -1;
	}

	free (ppMemAllocated[0]);
	free (ppMemAllocated);

	return 0;
}
void CIP_ProgrammingMyClass::MyClass_MakeGrayImagetoBMP()
{
	m_BMPheader.biWidth = m_uiWidth;
	m_BMPheader.biHeight = m_uiHeight;

	int i,j,idx = 0;

	m_pucBMP = (UCHAR*)calloc(sizeof(UCHAR), m_uiWidth * m_uiHeight * 3);

	for(i=m_uiHeight-1; i>=0; i--)
	{
		for(j=0; j<m_uiWidth; j++)
		{
			m_pucBMP[idx++] = m_pucImgbuf[i][j];
			m_pucBMP[idx++] = m_pucImgbuf[i][j];
			m_pucBMP[idx++] = m_pucImgbuf[i][j];
		}
	}
}

void CIP_ProgrammingMyClass::MyClass_MakeGrayImagetoBMP(UCHAR** Imgbuf)
{
	m_BMPheader.biWidth = m_uiWidth;
	m_BMPheader.biHeight = m_uiHeight;

	int i,j,idx = 0;

	m_pucBMP = (UCHAR*)calloc(sizeof(UCHAR), m_uiWidth * m_uiHeight * 3);

	for(i=m_uiHeight-1; i>=0; i--)
	{
		for(j=0; j<m_uiWidth; j++)
		{
			m_pucBMP[idx++] = Imgbuf[i][j];
			m_pucBMP[idx++] = Imgbuf[i][j];
			m_pucBMP[idx++] = Imgbuf[i][j];
		}
	}
}


void CIP_ProgrammingMyClass::MyClass_MakeHistogram(UCHAR** HistImgbuf, float HistArray[256])
{
	int i,j;
	int width = m_uiWidth;	             
	int height = m_uiHeight;

	//8-bit depth �ӽ� �迭 ����
	int Image_Histogram[256] = {0,};

	//Histogram Calculation
	for(i=0; i<height; i++)
	{
		for(j=0; j<width; j++)
		{
			Image_Histogram[HistImgbuf[i][j]]++;
		}
	}
	//Histogram Normalization
	float Image_Area = (float)(height*width);
	for(i=0; i<256; i++)
	{
		HistArray[i] = Image_Histogram[i]/Image_Area;
	}
}


void CIP_ProgrammingMyClass::MyClass_MakeHistogramEqualization ()
{
    int i,j;
    int width = m_uiWidth;
    int height = m_uiHeight;

    //���� ������ Histogram ����
    float Image_Histogram_Equalization[256] = {0,};
    MyClass_MakeHistogram(m_pucImgbuf, Image_Histogram_Equalization);

    //Histogram ���� �� ���
    double CDF[256] ={0.0, };
    CDF[0] = Image_Histogram_Equalization[0];
    for(i=1; i<256; i++)
    {
        CDF[i] = CDF[i-1] + Image_Histogram_Equalization[i];
    }

    //Histogram equalization ���� �޸� �Ҵ�
    m_pucHistEqualImgBuf = memory_alloc2D(height,width);

    //Histogram equalization image ����
    for(i=0; i<height; i++)
    {
        for(j=0; j<width; j++)
        {
            m_pucHistEqualImgBuf[i][j] =
                         (UCHAR) (CDF[m_pucImgbuf[i][j]]*255);
        }
    }
}

void CIP_ProgrammingMyClass::MyClass_COPY(CIP_ProgrammingMyClass *pImage)
{
	m_BMPheader = pImage->m_BMPheader;
	m_uiWidth   = pImage->m_uiWidth;
	m_uiHeight  = pImage->m_uiHeight;
	m_pucImgbuf = memory_alloc2D(m_uiHeight,m_uiWidth);
	for(int i=0; i<m_uiHeight; i++)
		memcpy(m_pucImgbuf[i],pImage->m_pucImgbuf[i],sizeof(UCHAR)*m_uiWidth);
}