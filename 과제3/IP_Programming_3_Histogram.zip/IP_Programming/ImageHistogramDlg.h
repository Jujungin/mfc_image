#pragma once


// CImageHistogramDlg dialog

class CImageHistogramDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CImageHistogramDlg)

public:
	CImageHistogramDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CImageHistogramDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

private:	
	float m_Histogram[256];
	
public:	
	void SetHistogram(float Histogram[256]);
	afx_msg void OnPaint();
};

