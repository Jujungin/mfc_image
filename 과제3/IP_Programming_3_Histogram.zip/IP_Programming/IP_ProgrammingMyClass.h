#pragma once

class CIP_ProgrammingMyClass
{
public:
	BITMAPINFOHEADER	m_BMPheader;

	UCHAR*				m_pucBMP;
	UCHAR**				m_pucImgbuf;
	UCHAR**				m_pucHistEqualImgBuf;
	
	UINT				m_uiHeight;
	UINT				m_uiWidth;


public:
public:
	CIP_ProgrammingMyClass(void);
	~CIP_ProgrammingMyClass(void);

	UCHAR** memory_alloc2D(UINT32 height, UINT32 width);
	int memory_free2D(UCHAR** ppMemAllocated);
	
	void MyClass_MakeGrayImagetoBMP();	
	void MyClass_MakeGrayImagetoBMP(UCHAR** Imgbuf);
	void MyClass_MakeHistogram(UCHAR** HistImgbuf, float HistArray[256]);
	void MyClass_MakeHistogramEqualization ();
	void MyClass_COPY(CIP_ProgrammingMyClass* pImage);
};
