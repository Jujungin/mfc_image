#pragma once
class CIP_Sobel
{
public:
	UCHAR**				m_pucSobelFilteringImgbuf;

public:
	CIP_Sobel();
	~CIP_Sobel();

	UCHAR** memory_alloc2D(int height, int width);
	int memory_free2D(UCHAR** ppMemAllocated);

	UCHAR** MakePaddingImage(UCHAR** imgbuf, int Mask_Size, int height, int width);
	void SobelFiltering(UCHAR**, int height, int width);
};

